package com.sky.dto;

import lombok.Data;

@Data
public class DataRequestDTO {
    private String identity;
    private String verifycode;
}
