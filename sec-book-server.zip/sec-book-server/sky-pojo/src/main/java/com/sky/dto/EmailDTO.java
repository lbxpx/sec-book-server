package com.sky.dto;

import lombok.Data;

@Data
public class EmailDTO {
    private String email;
    private String code;
}
