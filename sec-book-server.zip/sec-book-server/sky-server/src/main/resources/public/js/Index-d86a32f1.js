import{_ as r,b as e,c as s,A as t}from"./index-39fb7769.js";const n=r({},[["render",function(r,n,o,a,c,i){const u=e("router-view");return s(),t(u)}]]);export{n as default};
