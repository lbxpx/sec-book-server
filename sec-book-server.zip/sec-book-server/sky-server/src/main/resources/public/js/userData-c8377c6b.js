import{s as a}from"./employee-dfff52ba.js";const e=e=>a({url:`/api/userData/${e}`,method:"get"}),t=e=>a({url:"/api/userData",method:"put",data:{...e}});export{t as e,e as g};
