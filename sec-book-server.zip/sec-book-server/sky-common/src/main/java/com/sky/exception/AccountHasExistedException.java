package com.sky.exception;

public class AccountHasExistedException extends BaseException {
    public AccountHasExistedException(String msg) {
        super(msg);
    }
}
